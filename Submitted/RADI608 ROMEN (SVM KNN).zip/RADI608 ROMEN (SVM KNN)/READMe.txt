ROMEN SAMUEL WABINA | Student No. 6536435
PhD student, Data Science for Healthcare and Clinical Informatics 
Clinical Epidemiology and Biostatistics, Faculty of Medicine - Ramathibodi Hospital 
Mahidol University

RADI608 Data Mining and Machine Learning
Assignment for KNN and SVM:

├── KNN
│   ├── data
│   │	  ├── colon.csv
│   └── scripts
│	  ├── RADI608 KNN Assignment.ipynb
├── SVM
    ├── data
    │	  ├── colon.csv
    └── scripts
	  ├── RADI608 SVM Assignment.ipynb


You may also access the assignment through this GitHub Link:
https://github.com/rrwabina/RADI608/tree/main/Submitted